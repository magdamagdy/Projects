const express = require('express');
const app = express();
const mongoose = require('mongoose');
const cors = require('cors');
const helmet = require ('helmet');
const morgan = require ('morgan');

const UserSchema = require("./models/User");
const userRoute = require('./routes/users');
const authRoute = require('./routes/auth');

//app.use(express.json());//parser


// mongoose.connect(
//     process.env.MONGO_URL,
//     { useNewUrlParser: true, useUnifiedTopology: true },
//     () => {
//       //console.log("Connected to MongoDB");
//       app.listen(3000);
//     }
//   );

/////////


// const UserSchema = new mongoose.Schema(
//   {
//     username: {
//       type: String,
//       //required: true,
//       // min: 3,
//       // max: 20,
//       unique: true,
//     },
//     email: {
//       type: String,
//       //required: true,
//       //max: 50,
//       unique: true,
//     },
//     password: {
//       type: String,
//       //required: true,
//       //min: 6,
//     },
//     // balance:{
//     //     type:Number,
//     //     default:null
//     // },
//     // mobile_number:{
//     //     type:String,
//     //     default:null
//     // },
//     // profile_Picture: {
//     //   type: String,
//     //   default: "",
//     // },
//     // sold_item_income:{
//     //     type:Number,
//     //     default:null
//     // },
//     // purchased_item_cost:{
//     //     type:Number,
//     //     default:null
//     // },
//     region:{
//         type:String,
//         //require:true
//     }
    
//   },
//   { timestamps: true }
// );



////////
//connect to first server

// const connection1 = mongoose.createConnection(
// 	"mongodb+srv://server1:server1@cluster0.vtt0a.mongodb.net/server1?retryWrites=true&w=majority",
// 	{ useNewUrlParser: true, useUnifiedTopology: true },
// 	() => {
// 		console.log(`server1  is connected successfully `);
// 	}
// );
// const userModel1 = connection1.model("User",UserSchema);


//connect to second server
// const connection2 = mongoose.createConnection(
// 	"mongodb+srv://server2:server2@cluster0.uhp2r.mongodb.net/server2?retryWrites=true&w=majority",
// 	{ useNewUrlParser: true, useUnifiedTopology: true },
// 	() => {
// 		console.log(`server2  is connected successfully `);
// 	}
// );

//const userModel2 = connection2.model("User",User.schema);



///////////
// app.post('/api/users/add',async(req,res)=>{
//   try{
//       //generate new password
//       const salt = await bcrypt.genSalt(10);
//       const hashedPassword = await bcrypt.hash(req.body.password,salt)//to hash pass
//       // create new user 
//       const newUser = new userModel1({
//           username:req.body.username,
//           email:req.body.email,
//           password:hashedPassword,
//           region:req.body.region
//       });

//       //save user & respond
//       const user = await newUser.save();
//       res.status(200).json(user);
      
//   }
//   catch(err){
//       res.status(500).json(err);
//       console.log(err);
//   }
  
// });

///////////






//connect to third server
// const connection3 = mongoose.createConnection(
// 	"mongodb+srv://server3:server3@cluster0.7v7gj.mongodb.net/server3?retryWrites=true&w=majority",
// 	{ useNewUrlParser: true, useUnifiedTopology: true },
// 	() => {
// 		console.log(`server3  is connected successfully `);
// 	}
// );

//const userModel3 = connection3.model("User",User.schema);




//middlewares
app.use(express.json()); // parser 
//app.use(cookieParser()); 
app.use(helmet());
app.use(morgan('common'));
app.use(cors());
app.use('/api/users',userRoute);
app.use('/api/auth',authRoute);

app.listen(process.env.PORT ||3000, ()=>{
    console.log('listening to requests');
});

app.get('/',(req,res)=>{
    res.send("welcome to hompage");
})

//module.exports=userModel1;