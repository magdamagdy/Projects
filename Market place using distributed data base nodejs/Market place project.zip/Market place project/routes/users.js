const router = require('express').Router();
const bcrypt = require ('bcryptjs');
const mongoose = require('mongoose');
const UserSchema = require("../models/User");
const ProductSchema = require("../models/Product");
const CartSchema = require("../models/Cart");
const cors = require('cors');

var corsOptions = {
  
    "origin": "*",
    "methods": "GET,HEAD,PUT,PATCH,POST,DELETE",
    "preflightContinue": false,
    "optionsSuccessStatus": 200
  
}
//////////////
//connect to first server
const connection1 = mongoose.createConnection(
	"mongodb+srv://server1:server1@cluster0.vtt0a.mongodb.net/server1?retryWrites=true&w=majority",
	{ useNewUrlParser: true, useUnifiedTopology: true },
	() => {
		console.log(`server1  is connected successfully `);
	}
);
const userModel1 = connection1.model("User",UserSchema);
const productModel1 = connection1.model("Product",ProductSchema);
const cartModel1 = connection1.model("Cart",CartSchema);
//connect to second server
const connection2 = mongoose.createConnection(
	"mongodb+srv://server2:server2@cluster0.uhp2r.mongodb.net/server2?retryWrites=true&w=majority",
	{ useNewUrlParser: true, useUnifiedTopology: true },
	() => {
		console.log(`server2  is connected successfully `);
	}
);
const userModel2 = connection2.model("User",UserSchema);
const productModel2 = connection2.model("Product",ProductSchema);
const cartModel2 = connection2.model("Cart",CartSchema);
//connect to third server
const connection3 = mongoose.createConnection(
	"mongodb+srv://server3:server3@cluster0.7v7gj.mongodb.net/server3?retryWrites=true&w=majority",
	{ useNewUrlParser: true, useUnifiedTopology: true },
	() => {
		console.log(`server3  is connected successfully `);
	}
);
const userModel3 = connection3.model("User",UserSchema);
const productModel3 = connection3.model("Product",ProductSchema);
const cartModel3 = connection3.model("Cart",CartSchema);
//////////////

    //get user by Id
router.post('/getbyId',cors(corsOptions), async (req, res) => {
    try {
        if(req.body.region === 'Asia' || req.body.region === 'Europe')
        {
            const user = await userModel1.findById(req.body.id);
            
            res.status(200).json(user); 
        }
        else if (req.body.region === 'North America' || req.body.region === 'South America')
        {
            const user = await userModel2.findById(req.body.id);
            
            res.status(200).json(user); 
        }
        else
        {
            const user = await userModel3.findById(req.body.id);
            
            if(user)
            res.status(200).json(user);
            else
            res.status(200).json("user not found");
        }
                             
    } 
    catch (err) {
      res.status(200).json("user not found");
      console.log(err);
    }
  });


  //Edit user
router.put("/edit",cors(corsOptions), async (req, res) => {    
    if (req.body.password) {
    try {
        const salt = await bcrypt.genSalt(10);
        req.body.password = await bcrypt.hash(req.body.password, salt);
    } catch (err) {
        return res.status(200).json(err); 
    }
    }
    try {
        if(req.body.region === 'Asia' || req.body.region === 'Europe')
        {
            const user = await userModel1.findByIdAndUpdate(req.body.id, {
                $set: req.body, // to set all inputs inside this body (the body written in postman)
            });
            if(user)
            res.status(200).json("Success");
            else 
            res.status(200).json("user not found");
        }
        else if (req.body.region === 'North America' || req.body.region === 'South America')
        {
            const user = await userModel2.findByIdAndUpdate(req.body.id, {
                $set: req.body,
            });
            if(user)
            res.status(200).json("Success");
            else 
            res.status(200).json("user not found");
        }
        else
        {
            const user = await userModel3.findByIdAndUpdate(req.body.id, {
                $set: req.body,
            });
            if(user)
            res.status(200).json("Success");
            else 
            res.status(200).json("user not found");
        }
    }
    catch (err) {
    res.status(200).json("user not found");
    console.log(err);
    }
    
  });

  // get purchased products for specific user 
router.post('/purchased',cors(corsOptions), async (req, res) => {
    try{
        if(req.body.region === 'Asia' || req.body.region === 'Europe')
        {
            const PRODUCTS=[];
            const products = await productModel1.find({
                "user_id": req.body.id,
                "status": "purchased"
              });
            
            var owner =null ;  
            if(products){
              for(let i=0; i<products.length;i++)
              {
                const owner1 = await userModel1.findById(products[i].owner_id);  
                if(owner1 != null)  {owner=owner1;}
                const owner2 = await userModel2.findById(products[i].owner_id);  
                if(owner2 != null)  {owner=owner2;}
                const owner3 = await userModel3.findById(products[i].owner_id);  
                if(owner3 != null)  {owner=owner3;}

                PRODUCTS.push({"product":products[i], "username":owner.username});
              }
            res.status(200).json(PRODUCTS);
            }
            else 
            res.status(200).json("user not found");
        }
        else if (req.body.region === 'North America' || req.body.region === 'South America')
        {
            const PRODUCTS=[];
            const products = await productModel2.find({
                "user_id": req.body.id,
                "status": "purchased"
              });
            var owner =null ; 
            if(products)
            {
                for(let i=0; i<products.length;i++)
                {
                  const owner1 = await userModel1.findById(products[i].owner_id);  
                  if(owner1 != null)  {owner=owner1;}
                  const owner2 = await userModel2.findById(products[i].owner_id);  
                  if(owner2 != null)  {owner=owner2;}
                  const owner3 = await userModel3.findById(products[i].owner_id);  
                  if(owner3 != null)  {owner=owner3;}
  
                  PRODUCTS.push({"product":products[i], "username":owner.username});
                }
              res.status(200).json(PRODUCTS);
              }
            else 
            res.status(200).json("user not found");
        }
        else
        {
            const PRODUCTS=[];
            const products = await productModel3.find({
                "user_id": req.body.id,
                "status": "purchased"
              });
            var owner =null ;   
            if(products)
            {
                for(let i=0; i<products.length;i++)
                {
                  const owner1 = await userModel1.findById(products[i].owner_id);  
                  if(owner1 != null)  {owner=owner1;}
                  const owner2 = await userModel2.findById(products[i].owner_id);  
                  if(owner2 != null)  {owner=owner2;}
                  const owner3 = await userModel3.findById(products[i].owner_id);  
                  if(owner3 != null)  {owner=owner3;}
  
                  PRODUCTS.push({"product":products[i], "username":owner.username});
                }
              res.status(200).json(PRODUCTS);
              }
            else 
            res.status(200).json("user not found");
        }
    }
    catch (err) {
        res.status(200).json("user not found");
        console.log(err);
        }
});

    //add new product
router.post('/products/add',cors(corsOptions), async (req, res) => {
    try
    {
        if(req.body.region === 'Asia' || req.body.region === 'Europe'){
            const user = await userModel1.findById(req.body.id);
            if(user){
                newPouduct = await productModel1.create({
                user_id:req.body.id,
                type:req.body.type,
                name:req.body.name,
                quantity:req.body.quantity,
                post_date:Date.now(),
                status:"available",
                price:req.body.price,
                description:req.body.description,
                product_image:req.body.image
                });
                res.status(200).json("Success");
            }
            else
            res.status(200).json("user not found");
        }
        else if (req.body.region === 'North America' || req.body.region === 'South America')
        {
            const user = await userModel2.findById(req.body.id);
            if(user){
                newPouduct = await productModel2.create({
                user_id:req.body.id,
                type:req.body.type,
                name:req.body.name,
                quantity:req.body.quantity,
                post_date:Date.now(),
                status:"available",
                price:req.body.price,
                description:req.body.description,
                product_image:req.body.image
                });
                res.status(200).json("Success");
            }
            else
            res.status(200).json("user not found");
        }
        else
        {
            const user = await userModel3.findById(req.body.id);
            if(user){
                newPouduct = await productModel3.create({
                user_id:req.body.id,
                type:req.body.type,
                name:req.body.name,
                quantity:req.body.quantity,
                post_date:Date.now(),
                status:"available",
                price:req.body.price,
                description:req.body.description,
                product_image:req.body.image
                });
                res.status(200).json("Success");
            }
            else
            res.status(200).json("user not found");
        }
    }
    catch (err) {
        res.status(200).json("user not found");
        console.log(err);
        }
    });

    //filter product ny name 
    router.post('/products/filterbyname',cors(corsOptions), async (req, res) => {
        try {
            const products =[];
            const products1 = await productModel1.find({ name: { $regex : req.body.name} });
            if(products1)
            products.push(products1);

            const products2 = await productModel2.find({ name: { $regex : req.body.name} });
            if(products2)
            products.push(products2);

            const products3 = await productModel3.find({ name: { $regex : req.body.name} });
            if(products3)
            products.push(products3);

            res.status(200).json(products);                     
        } 
        catch (err) {
          res.status(200).json("name not found");
          console.log(err);
        }
      });

  // get availabe & sponsor products for specific user 
  router.post('/products',cors(corsOptions), async (req, res) => {
    try{
        var PROD=[];
        var owner =null;
        if(req.body.region === 'Asia' || req.body.region === 'Europe')
        {
            const products1 = await productModel1.find({
                "user_id": req.body.id,
              });
            if(products1)
            {
                for(let i=0; i<products1.length;i++)
                {
                    if(products1[i].status != "purchased"){

                        if(products1[i].status === "sponsor")
                        {
                            const owner1 = await userModel1.findById(products1[i].owner_id);
                            if(owner1 != null){owner = owner1;}
                            else
                            {
                                const owner2 = await userModel2.findById(products1[i].owner_id);
                                if(owner2 != null){owner = owner2;}
                                else
                                {
                                    const owner3 = await userModel3.findById(products1[i].owner_id);
                                    if(owner3 != null){owner = owner3;}
                                }
                            }
                            
                        }
                        else
                        {
                            owner = await userModel1.findById(req.body.id);
                        }
                        PROD.push({"product":products1[i],"ownername":owner.username});
                    }
                }
                res.status(200).json(PROD);
            }
            else 
            res.status(200).json(products1);
        }
        else if (req.body.region === 'North America' || req.body.region === 'South America')
        {
            const products2 = await productModel2.find({
                "user_id": req.body.id,
              });
            if(products2)
            {
                for(let i=0; i<products2.length;i++)
                {
                    if(products2[i].status != "purchased"){

                        if(products2[i].status === "sponsor")
                        {
                            const owner1 = await userModel1.findById(products2[i].owner_id);
                            if(owner1 != null){owner = owner1;}
                            else
                            {
                                const owner2 = await userModel2.findById(products2[i].owner_id);
                                if(owner2 != null){owner = owner2;}
                                else
                                {
                                    const owner3 = await userModel3.findById(products2[i].owner_id);
                                    if(owner3 != null){owner = owner3;}
                                }
                            }
                            
                        }
                        else
                        {
                            owner = await userModel2.findById(req.body.id);
                        }
                        PROD.push({"product":products2[i],"ownername":owner.username});
                    }
                }
                res.status(200).json(PROD);
            }
            else 
            res.status(200).json(products2);
        }
        else
        {
            const products3 = await productModel3.find({
                "user_id": req.body.id,
              });
            if(products3)
            {
                for(let i=0; i<products3.length;i++)
                {
                    if(products3[i].status != "purchased"){

                        if(products3[i].status === "sponsor")
                        {
                            const owner1 = await userModel1.findById(products3[i].owner_id);
                            if(owner1 != null){owner = owner1;}
                            else
                            {
                                const owner2 = await userModel2.findById(products3[i].owner_id);
                                if(owner2 != null){owner = owner2;}
                                else
                                {
                                    const owner3 = await userModel3.findById(products3[i].owner_id);
                                    if(owner3 != null){owner = owner3;}
                                }
                            }
                            
                        }
                        else
                        {
                            owner = await userModel3.findById(req.body.id);
                        }
                        PROD.push({"product":products3[i],"ownername":owner.username});
                    }
                }
                res.status(200).json(PROD);
            }
            else 
            res.status(200).json(products3);
        }
    }
    catch (err) {
        res.status(200).json("user not found");
        console.log(err);
        }
});

//get all products of certain type
router.post('/category/products',cors(corsOptions), async (req, res) => {
    try {
        var PROD=[];
        var owner =null;
        var sponsor = null;
        const products1 = await productModel1.find({ type: req.body.type}).populate("user_id");
        if(products1)
        {
            for(let i=0; i<products1.length;i++)
            {
                if(products1[i].status != "purchased"){
                    var owner1=null;var owner2=null;var owner3=null;
                    if(products1[i].status === "sponsor"){owner1 = await userModel1.findById(products1[i].owner_id);
                                                            if(owner1 != null)
                                                              {
                                                                  owner=owner1.username;
                                                              }
                                                              else
                                                              {
                                                                owner2 = await userModel2.findById(products1[i].owner_id);
                                                                if(owner2 != null)  
                                                                {
                                                                    owner=owner2.username;
                                                                }
                                                                else
                                                                {
                                                                    owner3 = await userModel3.findById(products1[i].owner_id);
                                                                    if(owner3 != null)  {owner=owner3.username;}
                                                                }
                                                              }

                                                             sponsor=products1[i].user_id.username;}
                    else
                    {
                        owner=products1[i].user_id.username;
                    }
                    // else {owner1 = await userModel1.findById(products1[i].user_id);}  
                    // if(owner1 != null)  {owner=owner1;}
                    
                   // var owner2=null;
                    //if(products1[i].status === "sponsor"){owner2 = await userModel2.findById(products1[i].owner_id); sponsor=products1[i].user_id.username;}
                    // else {owner2 = await userModel2.findById(products1[i].user_id);}
                    // if(owner2 != null)  {owner=owner2;}
                    
                   // var owner3=null;
                    //if(products1[i].status === "sponsor"){owner3 = await userModel3.findById(products1[i].owner_id); sponsor=products1[i].user_id.username;}
                    // else{owner3 = await userModel3.findById(products1[i].user_id); } 
                    // if(owner3 != null)  {owner=owner3;}

                    PROD.push({"product":products1[i],"ownername":owner,"sponsorname":sponsor});
                }
            }
        }
        const products2 = await productModel2.find({ type: req.body.type}).populate("user_id");
        if(products2)
        {
            for(let i=0; i<products2.length;i++)
            {
                if(products2[i].status != "purchased"){
                    var owner1=null;var owner2=null;var owner3=null;
                    if(products2[i].status === "sponsor"){owner1 = await userModel1.findById(products2[i].owner_id);
                                                            if(owner1 != null)
                                                              {
                                                                  owner=owner1.username;
                                                              }
                                                              else
                                                              {
                                                                owner2 = await userModel2.findById(products2[i].owner_id);
                                                                if(owner2 != null)  
                                                                {
                                                                    owner=owner2.username;
                                                                }
                                                                else
                                                                {
                                                                    owner3 = await userModel3.findById(products2[i].owner_id);
                                                                    if(owner3 != null)  {owner=owner3.username;}
                                                                }
                                                              }

                                                             sponsor=products2[i].user_id.username;}
                    else
                    {
                        owner=products2[i].user_id.username;
                    }
                    PROD.push({"product":products2[i],"ownername":owner,"sponsorname":sponsor});
                }
            }
        }

        const products3 = await productModel3.find({ type: req.body.type}).populate("user_id");
        if(products3)
        {
            for(let i=0; i<products3.length;i++)
            {
                if(products3[i].status != "purchased"){
                    var owner1=null;var owner2=null;var owner3=null;
                    if(products3[i].status === "sponsor"){owner1 = await userModel1.findById(products3[i].owner_id);
                                                            if(owner1 != null)
                                                              {
                                                                  owner=owner1.username;
                                                              }
                                                              else
                                                              {
                                                                owner2 = await userModel2.findById(products3[i].owner_id);
                                                                if(owner2 != null)  
                                                                {
                                                                    owner=owner2.username;
                                                                }
                                                                else
                                                                {
                                                                    owner3 = await userModel3.findById(products3[i].owner_id);
                                                                    if(owner3 != null)  {owner=owner3.username;}
                                                                }
                                                              }

                                                             sponsor=products3[i].user_id.username;}
                    else
                    {
                        owner=products3[i].user_id.username;
                    }
                    
                    PROD.push({"product":products3[i],"ownername":owner,"sponsorname":sponsor});
                }
            }
        }

        res.status(200).json(PROD);                     
    } 
    catch (err) {
      res.status(200).json("type not found");
      console.log(err);
    }
  });

  //add to cart from category page
  router.post('/category/AddToCart',cors(corsOptions), async (req, res) => {
    try
    {
        if(req.body.region === 'Asia' || req.body.region === 'Europe'){
            const user = await userModel1.findById(req.body.id);
            if(user){
                var product = null;
                const p1 = await productModel1.findById(req.body.product_id);
                if(p1 != null)  product =p1;
                const p2 = await productModel2.findById(req.body.product_id);
                if(p2 != null)  product =p2;
                const p3 = await productModel3.findById(req.body.product_id);
                if(p3 != null)  product =p3;

                if(req.body.quantity <= product.quantity){
                newCartPouduct = await cartModel1.create({
                    user_id:req.body.id,
                    product_id:req.body.product_id,
                    quantity:req.body.quantity,
                });
                res.status(200).json("Success");
            }
            else res.status(200).json("No such quantity");
            }
            else
            res.status(200).json("user not found");
        }
        else if (req.body.region === 'North America' || req.body.region === 'South America')
        {
            const user = await userModel2.findById(req.body.id);
            if(user){
                var product = null;
                const p1 = await productModel1.findById(req.body.product_id);
                if(p1 != null)  product =p1;
                const p2 = await productModel2.findById(req.body.product_id);
                if(p2 != null)  product =p2;
                const p3 = await productModel3.findById(req.body.product_id);
                if(p3 != null)  product =p3;

                if(req.body.quantity <= product.quantity){
                newCartPouduct = await cartModel2.create({
                    user_id:req.body.id,
                    product_id:req.body.product_id,
                    quantity:req.body.quantity,
                });
                res.status(200).json("Success");
            }
            else res.status(200).json("No such quantity");
            }
            else
            res.status(200).json("user not found");
        }
        else
        {
            const user = await userModel3.findById(req.body.id);
            if(user){
                var product = null;
                const p1 = await productModel1.findById(req.body.product_id);
                if(p1 != null)  product =p1;
                const p2 = await productModel2.findById(req.body.product_id);
                if(p2 != null)  product =p2;
                const p3 = await productModel3.findById(req.body.product_id);
                if(p3 != null)  product =p3;

                if(req.body.quantity <= product.quantity){
                newCartPouduct = await cartModel3.create({
                    user_id:req.body.id,
                    product_id:req.body.product_id,
                    quantity:req.body.quantity,
                });
                res.status(200).json("Success");
            }
            else res.status(200).json("No such quantity");
            }
            else
            res.status(200).json("user not found");
        }

    }
    catch (err) {
        res.status(200).json("user not found");
        console.log(err);
        }
    });

    
//filter product ny name 
    router.post('/products/filterbyname',cors(corsOptions), async (req, res) => {
        try {
            const products =[];
            const products1 = await productModel1.find({ name: { $regex : req.body.name},
                "status":{"$in":["available","sponsor","sold"]} });
            if(products1)
            products.push(products1);

            const products2 = await productModel2.find({ name: { $regex : req.body.name},
                "status":{"$in":["available","sponsor","sold"]} });
            if(products2)
            products.push(products2);

            const products3 = await productModel3.find({ name: { $regex : req.body.name},
                "status":{"$in":["available","sponsor","sold"]} });
            if(products3)
            products.push(products3);

            res.status(200).json(products);                     
        } 
        catch (err) {
          res.status(200).json("name not found");
          console.log(err);
        }
      });

      //filter product by name and type for category page
    router.post('/category/search',cors(corsOptions), async (req, res) => {
        try {
            var PROD=[];
            var owner =null;
            var sponsor = null;
            const products1 = await productModel1.find({ 
                name: { $regex : req.body.name},
                type: req.body.type,
             }).populate("user_id");
             if(products1)
             {
                 for(let i=0; i<products1.length;i++)
                 {
                     if(products1[i].status != "purchased"){
                         var owner1=null;var owner2=null;var owner3=null;
                         if(products1[i].status === "sponsor"){owner1 = await userModel1.findById(products1[i].owner_id);
                                                                 if(owner1 != null)
                                                                   {
                                                                       owner=owner1.username;
                                                                   }
                                                                   else
                                                                   {
                                                                     owner2 = await userModel2.findById(products1[i].owner_id);
                                                                     if(owner2 != null)  
                                                                     {
                                                                         owner=owner2.username;
                                                                     }
                                                                     else
                                                                     {
                                                                         owner3 = await userModel3.findById(products1[i].owner_id);
                                                                         if(owner3 != null)  {owner=owner3.username;}
                                                                     }
                                                                   }
     
                                                                  sponsor=products1[i].user_id.username;}
                         else
                         {
                             owner=products1[i].user_id.username;
                         }
                         
                         PROD.push({"product":products1[i],"ownername":owner,"sponsorname":sponsor});
                     }
                 }
             }
                 
            const products2 = await productModel2.find({ 
                name: { $regex : req.body.name},
                type: req.body.type,
             }).populate("user_id");
             if(products2)
             {
                 for(let i=0; i<products2.length;i++)
                 {
                     if(products2[i].status != "purchased"){
                         var owner1=null;var owner2=null;var owner3=null;
                         if(products2[i].status === "sponsor"){owner1 = await userModel1.findById(products2[i].owner_id);
                                                                 if(owner1 != null)
                                                                   {
                                                                       owner=owner1.username;
                                                                   }
                                                                   else
                                                                   {
                                                                     owner2 = await userModel2.findById(products2[i].owner_id);
                                                                     if(owner2 != null)  
                                                                     {
                                                                         owner=owner2.username;
                                                                     }
                                                                     else
                                                                     {
                                                                         owner3 = await userModel3.findById(products2[i].owner_id);
                                                                         if(owner3 != null)  {owner=owner3.username;}
                                                                     }
                                                                   }
     
                                                                  sponsor=products2[i].user_id.username;}
                         else
                         {
                             owner=products2[i].user_id.username;
                         }
                         PROD.push({"product":products2[i],"ownername":owner,"sponsorname":sponsor});
                     }
                 }
             }
     
            const products3 = await productModel3.find({ 
                name: { $regex : req.body.name},
                type: req.body.type,
             }).populate("user_id");
             if(products3)
             {
                 for(let i=0; i<products3.length;i++)
                 {
                     if(products3[i].status != "purchased"){
                         var owner1=null;var owner2=null;var owner3=null;
                         if(products3[i].status === "sponsor"){owner1 = await userModel1.findById(products3[i].owner_id);
                                                                 if(owner1 != null)
                                                                   {
                                                                       owner=owner1.username;
                                                                   }
                                                                   else
                                                                   {
                                                                     owner2 = await userModel2.findById(products3[i].owner_id);
                                                                     if(owner2 != null)  
                                                                     {
                                                                         owner=owner2.username;
                                                                     }
                                                                     else
                                                                     {
                                                                         owner3 = await userModel3.findById(products3[i].owner_id);
                                                                         if(owner3 != null)  {owner=owner3.username;}
                                                                     }
                                                                   }
     
                                                                  sponsor=products3[i].user_id.username;}
                         else
                         {
                             owner=products3[i].user_id.username;
                         }
                         
                         PROD.push({"product":products3[i],"ownername":owner,"sponsorname":sponsor});
                     }
                 }
             }
     
     
            res.status(200).json(PROD);                     
        } 
        catch (err) {
          res.status(200).json("product not found");
          console.log(err);
        }
      });


    //get all cart products for a certain user
router.post('/getCart',cors(corsOptions), async (req, res) => {
    try{
        if(req.body.region === 'Asia' || req.body.region === 'Europe')
        {
            const user = await userModel1.findById(req.body.id);
            if (user)
            {
                products=[];
                const cart =  await cartModel1.find({
                    "user_id": req.body.id,
                    });
                for (let i = 0; i < cart.length; i++) {
                    
                    const text = JSON.stringify(cart[i]);
                    const parsing= JSON.parse(text);
                    productID= parsing.product_id;
                    quantity= parsing.quantity;

                    const p1 = await productModel1.findById( productID);
                    const p2 = await productModel2.findById( productID);
                    const p3 = await productModel3.findById( productID);
                    if (p1 != null)
                    {
                        products.push({"product":p1,
                                        "quantity":quantity});
                    }
                    if (p2 != null)
                    {
                        products.push({"product":p2,
                                        "quantity":quantity});
                    }
                    if (p3 != null)
                    {
                        products.push({"product":p3,
                                        "quantity":quantity});
                    }
                }
                res.status(200).json(products);
            }
            else 
            res.status(200).json("user not found");
        }
        else if (req.body.region === 'North America' || req.body.region === 'South America')
        {
            const user = await userModel2.findById(req.body.id);
            if (user)
            {
                products=[];
                const cart =  await cartModel2.find({
                    "user_id": req.body.id,
                    });
                for (let i = 0; i < cart.length; i++) {
                    
                    const text = JSON.stringify(cart[i]);
                    const parsing= JSON.parse(text);
                    productID= parsing.product_id;
                    quantity= parsing.quantity;

                    const p1 = await productModel1.findById( productID);
                    const p2 = await productModel2.findById( productID);
                    const p3 = await productModel3.findById( productID);
                    if (p1 != null)
                    {
                        products.push({"product":p1,
                                        "quantity":quantity});
                    }
                    if (p2 != null)
                    {
                        products.push({"product":p2,
                                        "quantity":quantity});
                    }
                    if (p3 != null)
                    {
                        products.push({"product":p3,
                                        "quantity":quantity});
                    }
                }
                res.status(200).json(products);
            }
            else 
            res.status(200).json("user not found");
        }
        else
        {
            const user = await userModel3.findById(req.body.id);
            if (user)
            {
                products=[];
                const cart =  await cartModel3.find({
                    "user_id": req.body.id,
                    });
                for (let i = 0; i < cart.length; i++) {
                    
                    const text = JSON.stringify(cart[i]);
                    const parsing= JSON.parse(text);
                    productID= parsing.product_id;
                    quantity= parsing.quantity;

                    const p1 = await productModel1.findById( productID);
                    const p2 = await productModel2.findById( productID);
                    const p3 = await productModel3.findById( productID);
                    
                    if (p1 != null)
                    {
                        products.push({"product":p1,
                                        "quantity":quantity});
                    }
                    if (p2 != null)
                    {
                        products.push({"product":p2,
                                        "quantity":quantity});
                    }
                    if (p3 != null)
                    {
                        products.push({"product":p3,
                                        "quantity":quantity});
                    }
                }
                res.status(200).json(products);
            }
            else 
            res.status(200).json("user not found");
        }
    }
    catch (err) {
        res.status(200).json("user not found");
        console.log(err);
        }
});

// sponsor
router.post('/sponsor',cors(corsOptions), async (req, res) => {
    try
    {
        if(req.body.region === 'Asia' || req.body.region === 'Europe'){
            const user = await userModel1.findById(req.body.id);
            var product=null ;
            const p1 = await productModel1.findById(req.body.product_id);
            if(p1 != null)  {product =p1};
            const p2 = await productModel2.findById(req.body.product_id);
            if(p2 != null)  {product =p2};
            const p3 = await productModel3.findById(req.body.product_id);
            if(p3 != null)  {product = p3};
            if(user){
                newPouduct = await productModel1.create({
                user_id:req.body.id,
                type:product.type,
                name:product.name,
                quantity:product.quantity,
                post_date:Date.now(),
                status:"sponsor",
                owner_id:product.user_id,
                price:product.price,
                description:product.description,
                product_image:product.product_image
                });
                res.status(200).json("Success");
            }
            else
            res.status(200).json("user not found");
        }
        else if (req.body.region === 'North America' || req.body.region === 'South America')
        {
            const user = await userModel2.findById(req.body.id);
            var product=null ;
            const p1 = await productModel1.findById(req.body.product_id);
            if(p1 != null)  {product =p1};
            const p2 = await productModel2.findById(req.body.product_id);
            if(p2 != null)  {product =p2};
            const p3 = await productModel3.findById(req.body.product_id);
            if(p3 != null)  {product = p3};
            if(user){
                newPouduct = await productModel2.create({
                user_id:req.body.id,
                type:product.type,
                name:product.name,
                quantity:product.quantity,
                post_date:Date.now(),
                status:"sponsor",
                owner_id:product.user_id,
                price:product.price,
                description:product.description,
                product_image:product.product_image
                });
                res.status(200).json("Success");
            }
            else
            res.status(200).json("user not found");
        }
        else
        {
            const user = await userModel3.findById(req.body.id);
            var product=null ;
            const p1 = await productModel1.findById(req.body.product_id);
            if(p1 != null)  {product =p1};
            const p2 = await productModel2.findById(req.body.product_id);
            if(p2 != null)  {product =p2};
            const p3 = await productModel3.findById(req.body.product_id);
            if(p3 != null)  {product = p3};
            if(user){
                newPouduct = await productModel3.create({
                user_id:req.body.id,
                type:product.type,
                name:product.name,
                quantity:product.quantity,
                post_date:Date.now(),
                status:"sponsor",
                owner_id:product.user_id,
                price:product.price,
                description:product.description,
                product_image:product.product_image
                });
                res.status(200).json("Success");
            }
            else
            res.status(200).json("user not found");
        }
    }
    catch (err) {
        res.status(200).json("user not foundlast");
        console.log(err);
        }
});

// checkout in cart page
router.post('/checkout',cors(corsOptions), async (req, res) => {
    try
    {
        if(req.body.region === 'Asia' || req.body.region === 'Europe'){
            const user = await userModel1.findById(req.body.id);
            var product=null ;
            const p1 = await productModel1.findById(req.body.product_id);
            if(p1 != null)  {product =p1};
            const p2 = await productModel2.findById(req.body.product_id);
            if(p2 != null)  {product =p2};
            const p3 = await productModel3.findById(req.body.product_id);
            if(p3 != null)  {product = p3};
           
            if(user)
            {
                if (user.balance >= req.body.total_amount)
                {
                    newPouduct = await productModel1.create({
                        user_id:req.body.id,
                        type:product.type,
                        name:product.name,
                        quantity:req.body.quantity,
                        post_date:Date.now(),
                        status:"purchased",
                        price:product.price,
                        description:product.description,
                        product_image:product.product_image,
                        owner_id:product.user_id
                        });
                    
                    //console.log("product created successfully",newPouduct);
                    await userModel1.findByIdAndUpdate(req.body.id, 
                        {
                        balance: user.balance - req.body.total_amount,
                        purchased_item_cost: user.purchased_item_cost + req.body.total_amount,
                        });   

                    if (product.status === "sponsor")  // if the seller is sponsor
                    { console.log("spnsor path");
                        var flag=0;
                        const sponsor1 = await userModel1.findById(product.user_id);  
                        if(sponsor1 != null)  flag = 1;
                        const sponsor2 = await userModel2.findById(product.user_id);  
                        if(sponsor2 != null)  flag = 2;
                        const sponsor3 = await userModel3.findById(product.user_id);  
                        if(sponsor3 != null)  flag = 3;

                        if (flag === 1 )
                        {
                            await productModel1.findByIdAndUpdate(product.id, 
                                {
                                    quantity: product.quantity - req.body.quantity
                                });     
                        }
                        if (flag === 2 )
                        {
                            await productModel2.findByIdAndUpdate(product.id, 
                                {
                                    quantity: product.quantity - req.body.quantity
                                });     
                        }      
                        if (flag === 3 )
                        {
                            await productModel3.findByIdAndUpdate(product.id, 
                                {
                                    quantity: product.quantity - req.body.quantity
                                });     
                        }    
                            // owner may be @ any server  update sold item income and quantity
                            // sold item income update
                            var owner_Flag=0;
                            var owner = null;
                            var prod = null;
                            const owner1 = await userModel1.findById(product.owner_id);  
                            if(owner1 != null)  {owner_Flag = 1; owner=owner1; prod =await productModel1.findOne({user_id:product.owner_id, name:product.name, type:product.type});}
                            const owner2 = await userModel2.findById(product.owner_id);  
                            if(owner2 != null)  {owner_Flag = 2; owner=owner2; prod =await productModel2.findOne({user_id:product.owner_id, name:product.name, type:product.type});}
                            const owner3 = await userModel3.findById(product.owner_id);  
                            if(owner3 != null)  {owner_Flag = 3; owner=owner3; prod =await productModel3.findOne({user_id:product.owner_id, name:product.name, type:product.type});}
                            
                            console.log("owner_Flag",owner_Flag,"prod",prod ,"prod.id",prod.id);
                            
                            //server1
                            if(owner_Flag === 1)
                            {
                                await userModel1.findByIdAndUpdate(product.owner_id, 
                                    {
                                        sold_item_income: owner.sold_item_income + req.body.total_amount
                                    }); 

                            
                                await productModel1.findByIdAndUpdate(prod.id, 
                                    { 
                                        quantity: prod.quantity - req.body.quantity
                                    });
                              
                            }
                            //server2
                            if(owner_Flag === 2)
                            {
                                await userModel2.findByIdAndUpdate(product.owner_id, 
                                    {
                                        sold_item_income: owner.sold_item_income + req.body.total_amount
                                    });

                                await productModel2.findByIdAndUpdate(prod.id, 
                                    { 
                                        quantity: prod.quantity - req.body.quantity
                                    });
                                 
                            }
                            //server3
                            if(owner_Flag === 3)
                            {
                                await userModel3.findByIdAndUpdate(product.owner_id, 
                                    {
                                        sold_item_income: owner.sold_item_income + req.body.total_amount
                                    });

                                await productModel3.findByIdAndUpdate(prod.id, 
                                    { 
                                        quantity: prod.quantity - req.body.quantity
                                    });
                            } 
                            
                    } 
                    
                   else // owner is the seller with status available
                    {console.log("else");
                        var flag=0;
                        var owner = null;
                        const owner1 = await userModel1.findById(product.user_id);  
                        if(owner1 != null)  {flag = 1; owner=owner1;}
                        const owner2 = await userModel2.findById(product.user_id);  
                        if(owner2 != null)  {flag = 2; owner=owner2;}
                        const owner3 = await userModel3.findById(product.user_id);  
                        if(owner3 != null)  {flag = 3; owner=owner3;}
                        
                        
                        if (flag === 1 )
                        {console.log("tmam1");
                            await userModel1.findByIdAndUpdate(product.user_id, 
                                {
                                    sold_item_income: owner.sold_item_income + req.body.total_amount
                                });  
                            await productModel1.findByIdAndUpdate(product.id, 
                                {
                                    quantity: product.quantity - req.body.quantity
                                });     
                                console.log("tmam1");
                            }
                        if (flag === 2 )
                        {   console.log("tmam2");
                            await userModel2.findByIdAndUpdate(product.user_id, 
                                {
                                    sold_item_income: owner.sold_item_income + req.body.total_amount
                                });  
                            await productModel2.findByIdAndUpdate(product.id, 
                                {
                                    quantity: product.quantity - req.body.quantity
                                });     
                                console.log("tmam2");
                            }
                        if (flag === 3 )
                        {
                            console.log("tmam3");
                            await userModel3.findByIdAndUpdate(product.user_id, 
                                {
                                    sold_item_income: owner.sold_item_income + req.body.total_amount
                                });  
                            console.log(product.id);
                            await productModel3.findByIdAndUpdate(product.id, 
                                {
                                    quantity: product.quantity - req.body.quantity
                                });     
                                console.log("tmam3");
                            }

                                //sponsors in 3 servers UPDATE QUANTITY
                                // server1
                            const s1 = await productModel1.find({owner_id: product.user_id,
                                                                     status:"sponsor"});
                            if(s1 != null){    
                                        
                            for(let i = 0; i < s1.length; i++)    
                            {
                                const text = JSON.stringify(s1[i]);
                                const parsing= JSON.parse(text);
                                productID= parsing._id; //console.log("productID",productID);
                                QUAUNTITY =parsing.quantity;//console.log("QUAUNTITY",QUAUNTITY);
                                
                                await productModel1.findByIdAndUpdate(productID, 
                                {
                                   quantity:QUAUNTITY - req.body.quantity
                                    
                                });  
                            }  
                            
                            }
                            // server2 
                            const s2 = await productModel2.find({owner_id: product.user_id,
                                                                   status:"sponsor"});
                                if(s2 != null){                                             
                                   
                                for(let i = 0; i < s2.length; i++)    
                            {
                                const text = JSON.stringify(s2[i]);
                                const parsing= JSON.parse(text);
                                productID= parsing._id; //console.log("productID",productID);
                                QUAUNTITY =parsing.quantity;//console.log("QUAUNTITY",QUAUNTITY);
                                
                                await productModel2.findByIdAndUpdate(productID, 
                                {
                                   quantity:QUAUNTITY - req.body.quantity
                                    
                                });  
                                }   
                             } 
                            //server3                                  
                            const s3 = await productModel3.find({owner_id: product.user_id,
                                                                        status:"sponsor"});
                                if(s3 != null){                                             
                                    for(let i = 0; i < s3.length; i++)    
                                    {
                                        const text = JSON.stringify(s3[i]);
                                        const parsing= JSON.parse(text);
                                        productID= parsing._id;// console.log("productID",productID);
                                        QUAUNTITY =parsing.quantity;//console.log("QUAUNTITY",QUAUNTITY);
                                        
                                        await productModel3.findByIdAndUpdate(productID, 
                                        {
                                            quantity:QUAUNTITY - req.body.quantity
                                            
                                        });  
                                    }   
                                }
                          
                    } 
                res.status(200).json("Success");
                }
                else res.status(200).json("no sufficient balance");
            }
            else
            res.status(200).json("user not found");
        }
        else if (req.body.region === 'North America' || req.body.region === 'South America')
        {
            const user = await userModel2.findById(req.body.id);
            var product=null ;
            const p1 = await productModel1.findById(req.body.product_id);
            if(p1 != null)  {product =p1};
            const p2 = await productModel2.findById(req.body.product_id);
            if(p2 != null)  {product =p2};
            const p3 = await productModel3.findById(req.body.product_id);
            if(p3 != null)  {product = p3};
           
            if(user)
            {
                if (user.balance >= req.body.total_amount)
                {
                    newPouduct = await productModel2.create({
                        user_id:req.body.id,
                        type:product.type,
                        name:product.name,
                        quantity:req.body.quantity,
                        post_date:Date.now(),
                        status:"purchased",
                        price:product.price,
                        description:product.description,
                        product_image:product.product_image,
                        owner_id:product.user_id
                        });
                    
                    //console.log("product created successfully",newPouduct);
                    await userModel2.findByIdAndUpdate(req.body.id, 
                        {
                        balance: user.balance - req.body.total_amount,
                        purchased_item_cost: user.purchased_item_cost + req.body.total_amount,
                        });   

                    if (product.status === "sponsor")  // if the seller is sponsor
                    { console.log("spnsor path");
                        var flag=0;
                        const sponsor1 = await userModel1.findById(product.user_id);  
                        if(sponsor1 != null)  flag = 1;
                        const sponsor2 = await userModel2.findById(product.user_id);  
                        if(sponsor2 != null)  flag = 2;
                        const sponsor3 = await userModel3.findById(product.user_id);  
                        if(sponsor3 != null)  flag = 3;

                        if (flag === 1 )
                        {
                            await productModel1.findByIdAndUpdate(product.id, 
                                {
                                    quantity: product.quantity - req.body.quantity
                                });     
                        }
                        if (flag === 2 )
                        {
                            await productModel2.findByIdAndUpdate(product.id, 
                                {
                                    quantity: product.quantity - req.body.quantity
                                });     
                        }      
                        if (flag === 3 )
                        {
                            await productModel3.findByIdAndUpdate(product.id, 
                                {
                                    quantity: product.quantity - req.body.quantity
                                });     
                        }    
                            // owner may be @ any server  update sold item income and quantity
                            // sold item income update
                            var owner_Flag=0;
                            var owner = null;
                            var prod = null;
                            const owner1 = await userModel1.findById(product.owner_id);  
                            if(owner1 != null)  {owner_Flag = 1; owner=owner1; prod =await productModel1.findOne({user_id:product.owner_id, name:product.name, type:product.type});}
                            const owner2 = await userModel2.findById(product.owner_id);  
                            if(owner2 != null)  {owner_Flag = 2; owner=owner2; prod =await productModel2.findOne({user_id:product.owner_id, name:product.name, type:product.type});}
                            const owner3 = await userModel3.findById(product.owner_id);  
                            if(owner3 != null)  {owner_Flag = 3; owner=owner3; prod =await productModel3.findOne({user_id:product.owner_id, name:product.name, type:product.type});}
                            
                            console.log("owner_Flag",owner_Flag,"prod",prod ,"prod.id",prod.id);
                            
                            //server1
                            if(owner_Flag === 1)
                            {
                                await userModel1.findByIdAndUpdate(product.owner_id, 
                                    {
                                        sold_item_income: owner.sold_item_income + req.body.total_amount
                                    }); 

                            
                                await productModel1.findByIdAndUpdate(prod.id, 
                                    { 
                                        quantity: prod.quantity - req.body.quantity
                                    });
                              
                            }
                            //server2
                            if(owner_Flag === 2)
                            {
                                await userModel2.findByIdAndUpdate(product.owner_id, 
                                    {
                                        sold_item_income: owner.sold_item_income + req.body.total_amount
                                    });

                                await productModel2.findByIdAndUpdate(prod.id, 
                                    { 
                                        quantity: prod.quantity - req.body.quantity
                                    });
                                 
                            }
                            //server3
                            if(owner_Flag === 3)
                            {
                                await userModel3.findByIdAndUpdate(product.owner_id, 
                                    {
                                        sold_item_income: owner.sold_item_income + req.body.total_amount
                                    });

                                await productModel3.findByIdAndUpdate(prod.id, 
                                    { 
                                        quantity: prod.quantity - req.body.quantity
                                    });
                            } 
                            
                    } 
                    
                   else // owner is the seller with status available
                    {console.log("else");
                        var flag=0;
                        var owner = null;
                        const owner1 = await userModel1.findById(product.user_id);  
                        if(owner1 != null)  {flag = 1; owner=owner1;}
                        const owner2 = await userModel2.findById(product.user_id);  
                        if(owner2 != null)  {flag = 2; owner=owner2;}
                        const owner3 = await userModel3.findById(product.user_id);  
                        if(owner3 != null)  {flag = 3; owner=owner3;}
                        
                        
                        if (flag === 1 )
                        {console.log("tmam1");
                            await userModel1.findByIdAndUpdate(product.user_id, 
                                {
                                    sold_item_income: owner.sold_item_income + req.body.total_amount
                                });  
                            await productModel1.findByIdAndUpdate(product.id, 
                                {
                                    quantity: product.quantity - req.body.quantity
                                });     
                                console.log("tmam1");
                            }
                        if (flag === 2 )
                        {   console.log("tmam2");
                            await userModel2.findByIdAndUpdate(product.user_id, 
                                {
                                    sold_item_income: owner.sold_item_income + req.body.total_amount
                                });  
                            await productModel2.findByIdAndUpdate(product.id, 
                                {
                                    quantity: product.quantity - req.body.quantity
                                });     
                                console.log("tmam2");
                            }
                        if (flag === 3 )
                        {
                            console.log("tmam3");
                            await userModel3.findByIdAndUpdate(product.user_id, 
                                {
                                    sold_item_income: owner.sold_item_income + req.body.total_amount
                                });  
                            console.log(product.id);
                            await productModel3.findByIdAndUpdate(product.id, 
                                {
                                    quantity: product.quantity - req.body.quantity
                                });     
                                console.log("tmam3");
                            }

                                //sponsors in 3 servers UPDATE QUANTITY
                                // server1
                            const s1 = await productModel1.find({owner_id: product.user_id,
                                                                     status:"sponsor"});
                            if(s1 != null){    
                                        
                            for(let i = 0; i < s1.length; i++)    
                            {
                                const text = JSON.stringify(s1[i]);
                                const parsing= JSON.parse(text);
                                productID= parsing._id; //console.log("productID",productID);
                                QUAUNTITY =parsing.quantity;//console.log("QUAUNTITY",QUAUNTITY);
                                
                                await productModel1.findByIdAndUpdate(productID, 
                                {
                                   quantity:QUAUNTITY - req.body.quantity
                                    
                                });  
                            }  
                            
                            }
                            // server2 
                            const s2 = await productModel2.find({owner_id: product.user_id,
                                                                   status:"sponsor"});
                                if(s2 != null){                                             
                                   
                                for(let i = 0; i < s2.length; i++)    
                            {
                                const text = JSON.stringify(s2[i]);
                                const parsing= JSON.parse(text);
                                productID= parsing._id; //console.log("productID",productID);
                                QUAUNTITY =parsing.quantity;//console.log("QUAUNTITY",QUAUNTITY);
                                
                                await productModel2.findByIdAndUpdate(productID, 
                                {
                                   quantity:QUAUNTITY - req.body.quantity
                                    
                                });  
                                }   
                             } 
                            //server3                                  
                            const s3 = await productModel3.find({owner_id: product.user_id,
                                                                        status:"sponsor"});
                                if(s3 != null){                                             
                                    for(let i = 0; i < s3.length; i++)    
                                    {
                                        const text = JSON.stringify(s3[i]);
                                        const parsing= JSON.parse(text);
                                        productID= parsing._id;// console.log("productID",productID);
                                        QUAUNTITY =parsing.quantity;//console.log("QUAUNTITY",QUAUNTITY);
                                        
                                        await productModel3.findByIdAndUpdate(productID, 
                                        {
                                            quantity:QUAUNTITY - req.body.quantity
                                            
                                        });  
                                    }   
                                }
                          
                    } 
                res.status(200).json("Success");
                }
                else res.status(200).json("no sufficient balance");
            }
            else
            res.status(200).json("user not found");   
        }
        else
        {
            const user = await userModel3.findById(req.body.id);
            var product=null ;
            const p1 = await productModel1.findById(req.body.product_id);
            if(p1 != null)  {product =p1};
            const p2 = await productModel2.findById(req.body.product_id);
            if(p2 != null)  {product =p2};
            const p3 = await productModel3.findById(req.body.product_id);
            if(p3 != null)  {product = p3};
           
            if(user)
            {
                if (user.balance >= req.body.total_amount)
                {
                    newPouduct = await productModel3.create({
                        user_id:req.body.id,
                        type:product.type,
                        name:product.name,
                        quantity:req.body.quantity,
                        post_date:Date.now(),
                        status:"purchased",
                        price:product.price,
                        description:product.description,
                        product_image:product.product_image,
                        owner_id:product.user_id
                        });
                    
                    //console.log("product created successfully",newPouduct);
                    await userModel3.findByIdAndUpdate(req.body.id, 
                        {
                        balance: user.balance - req.body.total_amount,
                        purchased_item_cost: user.purchased_item_cost + req.body.total_amount,
                        });   

                    if (product.status === "sponsor")  // if the seller is sponsor
                    { console.log("spnsor path");
                        var flag=0;
                        const sponsor1 = await userModel1.findById(product.user_id);  
                        if(sponsor1 != null)  flag = 1;
                        const sponsor2 = await userModel2.findById(product.user_id);  
                        if(sponsor2 != null)  flag = 2;
                        const sponsor3 = await userModel3.findById(product.user_id);  
                        if(sponsor3 != null)  flag = 3;

                        if (flag === 1 )
                        {
                            await productModel1.findByIdAndUpdate(product.id, 
                                {
                                    quantity: product.quantity - req.body.quantity
                                });     
                        }
                        if (flag === 2 )
                        {
                            await productModel2.findByIdAndUpdate(product.id, 
                                {
                                    quantity: product.quantity - req.body.quantity
                                });     
                        }      
                        if (flag === 3 )
                        {
                            await productModel3.findByIdAndUpdate(product.id, 
                                {
                                    quantity: product.quantity - req.body.quantity
                                });     
                        }    
                            // owner may be @ any server  update sold item income and quantity
                            // sold item income update
                            var owner_Flag=0;
                            var owner = null;
                            var prod = null;
                            const owner1 = await userModel1.findById(product.owner_id);  
                            if(owner1 != null)  {owner_Flag = 1; owner=owner1; prod =await productModel1.findOne({user_id:product.owner_id, name:product.name, type:product.type});}
                            const owner2 = await userModel2.findById(product.owner_id);  
                            if(owner2 != null)  {owner_Flag = 2; owner=owner2; prod =await productModel2.findOne({user_id:product.owner_id, name:product.name, type:product.type});}
                            const owner3 = await userModel3.findById(product.owner_id);  
                            if(owner3 != null)  {owner_Flag = 3; owner=owner3; prod =await productModel3.findOne({user_id:product.owner_id, name:product.name, type:product.type});}
                            
                            console.log("owner_Flag",owner_Flag,"prod",prod ,"prod.id",prod.id);
                            
                            //server1
                            if(owner_Flag === 1)
                            {
                                await userModel1.findByIdAndUpdate(product.owner_id, 
                                    {
                                        sold_item_income: owner.sold_item_income + req.body.total_amount
                                    }); 

                            
                                await productModel1.findByIdAndUpdate(prod.id, 
                                    { 
                                        quantity: prod.quantity - req.body.quantity
                                    });
                              
                            }
                            //server2
                            if(owner_Flag === 2)
                            {
                                await userModel2.findByIdAndUpdate(product.owner_id, 
                                    {
                                        sold_item_income: owner.sold_item_income + req.body.total_amount
                                    });

                                await productModel2.findByIdAndUpdate(prod.id, 
                                    { 
                                        quantity: prod.quantity - req.body.quantity
                                    });
                                 
                            }
                            //server3
                            if(owner_Flag === 3)
                            {
                                await userModel3.findByIdAndUpdate(product.owner_id, 
                                    {
                                        sold_item_income: owner.sold_item_income + req.body.total_amount
                                    });

                                await productModel3.findByIdAndUpdate(prod.id, 
                                    { 
                                        quantity: prod.quantity - req.body.quantity
                                    });
                            } 
                            
                    } 
                    
                   else // owner is the seller with status available
                    {console.log("else");
                        var flag=0;
                        var owner = null;
                        const owner1 = await userModel1.findById(product.user_id);  
                        if(owner1 != null)  {flag = 1; owner=owner1;}
                        const owner2 = await userModel2.findById(product.user_id);  
                        if(owner2 != null)  {flag = 2; owner=owner2;}
                        const owner3 = await userModel3.findById(product.user_id);  
                        if(owner3 != null)  {flag = 3; owner=owner3;}
                        
                        
                        if (flag === 1 )
                        {console.log("tmam1");
                            await userModel1.findByIdAndUpdate(product.user_id, 
                                {
                                    sold_item_income: owner.sold_item_income + req.body.total_amount
                                });  
                            await productModel1.findByIdAndUpdate(product.id, 
                                {
                                    quantity: product.quantity - req.body.quantity
                                });     
                                console.log("tmam1");
                            }
                        if (flag === 2 )
                        {   console.log("tmam2");
                            await userModel2.findByIdAndUpdate(product.user_id, 
                                {
                                    sold_item_income: owner.sold_item_income + req.body.total_amount
                                });  
                            await productModel2.findByIdAndUpdate(product.id, 
                                {
                                    quantity: product.quantity - req.body.quantity
                                });     
                                console.log("tmam2");
                            }
                        if (flag === 3 )
                        {
                            console.log("tmam3");
                            await userModel3.findByIdAndUpdate(product.user_id, 
                                {
                                    sold_item_income: owner.sold_item_income + req.body.total_amount
                                });  
                            console.log(product.id);
                            await productModel3.findByIdAndUpdate(product.id, 
                                {
                                    quantity: product.quantity - req.body.quantity
                                });     
                                console.log("tmam3");
                            }

                                //sponsors in 3 servers UPDATE QUANTITY
                                // server1
                            const s1 = await productModel1.find({owner_id: product.user_id,
                                                                     status:"sponsor"});
                            if(s1 != null){    
                                        
                            for(let i = 0; i < s1.length; i++)    
                            {
                                const text = JSON.stringify(s1[i]);
                                const parsing= JSON.parse(text);
                                productID= parsing._id; //console.log("productID",productID);
                                QUAUNTITY =parsing.quantity;//console.log("QUAUNTITY",QUAUNTITY);
                                
                                await productModel1.findByIdAndUpdate(productID, 
                                {
                                   quantity:QUAUNTITY - req.body.quantity
                                    
                                });  
                            }  
                            
                            }
                            // server2 
                            const s2 = await productModel2.find({owner_id: product.user_id,
                                                                   status:"sponsor"});
                                if(s2 != null){                                             
                                   
                                for(let i = 0; i < s2.length; i++)    
                            {
                                const text = JSON.stringify(s2[i]);
                                const parsing= JSON.parse(text);
                                productID= parsing._id; //console.log("productID",productID);
                                QUAUNTITY =parsing.quantity;//console.log("QUAUNTITY",QUAUNTITY);
                                
                                await productModel2.findByIdAndUpdate(productID, 
                                {
                                   quantity:QUAUNTITY - req.body.quantity
                                    
                                });  
                                }   
                             } 
                            //server3                                  
                            const s3 = await productModel3.find({owner_id: product.user_id,
                                                                        status:"sponsor"});
                                if(s3 != null){                                             
                                    for(let i = 0; i < s3.length; i++)    
                                    {
                                        const text = JSON.stringify(s3[i]);
                                        const parsing= JSON.parse(text);
                                        productID= parsing._id;// console.log("productID",productID);
                                        QUAUNTITY =parsing.quantity;//console.log("QUAUNTITY",QUAUNTITY);
                                        
                                        await productModel3.findByIdAndUpdate(productID, 
                                        {
                                            quantity:QUAUNTITY - req.body.quantity
                                            
                                        });  
                                    }   
                                }
                          
                    } 
                res.status(200).json("Success");
                }
                else res.status(200).json("no sufficient balance");
            }
            else
            res.status(200).json("user not found");
        }
    }
    catch (err) {
        res.status(200).json("user not found");
        console.log(err);
        }
});

//report of purchased items
router.post('/purchasedReport',cors(corsOptions), async (req, res) => {
    try
    {
        var WOMEN_COUNT =0, MEN_COUNT=0, CHILDREN_COUNT=0;
        if(req.body.region === 'Asia' || req.body.region === 'Europe')
        {
            const user = await userModel1.findById(req.body.id);
            if(user)
            {
               const women_count = await productModel1.find({ 
                post_date: {
                        $gte: new Date(req.body.startDate), 
                        $lte: new Date(req.body.endDate)
                    },               
                    status:"purchased",
                    user_id:req.body.id,
                    type: "women"
                },
                {
                    quantity: 1,
                });    
                for(let i =0; i<women_count.length;i++)
                {
                    WOMEN_COUNT += women_count[i].quantity;
                }
                
                const men_count = await productModel1.find({ 
                    post_date: {
                            $gte: new Date(req.body.startDate),
                            $lte: new Date(req.body.endDate)
                        },
                        status:"purchased",
                        user_id:req.body.id,
                        type: "men"
                    },
                    {
                        quantity: 1,
                    });    
                    for(let i =0; i<men_count.length;i++)
                    {
                        MEN_COUNT += men_count[i].quantity;
                    }           
                const children_count = await productModel1.find({ 
                    post_date: {
                            $gte: new Date(req.body.startDate),
                            $lte: new Date(req.body.endDate)
                        },
                        status:"purchased",
                        user_id:req.body.id,
                        type: "children"
                    },
                    {
                        quantity: 1,
                    });    
                    for(let i =0; i<children_count.length;i++)
                    {
                        CHILDREN_COUNT += children_count[i].quantity;
                    }                     
                    res.status(200).json({"data":[WOMEN_COUNT,MEN_COUNT,CHILDREN_COUNT]});      
            }
            else res.status(200).json("user not found");
        }
        else if (req.body.region === 'North America' || req.body.region === 'South America')
        {
            const user = await userModel2.findById(req.body.id);
            if(user)
            {
               const women_count = await productModel2.find({ 
                post_date: {
                        $gte: new Date(req.body.startDate), 
                        $lte: new Date(req.body.endDate)
                    },               
                    status:"purchased",
                    user_id:req.body.id,
                    type: "women"
                },
                {
                    quantity: 1,
                })/*.count()*/; 
                for(let i =0; i<women_count.length;i++)
                {
                    WOMEN_COUNT += women_count[i].quantity;
                }

                const men_count = await productModel2.find({ 
                    post_date: {
                            $gte: new Date(req.body.startDate),
                            $lte: new Date(req.body.endDate)
                        },
                        status:"purchased",
                        user_id:req.body.id,
                        type: "men"
                    },
                    {
                        quantity: 1,
                    });    
                    for(let i =0; i<men_count.length;i++)
                    {
                        MEN_COUNT += men_count[i].quantity;
                    }                
                const children_count = await productModel2.find({ 
                    post_date: {
                            $gte: new Date(req.body.startDate),
                            $lte: new Date(req.body.endDate)
                        },
                        status:"purchased",
                        user_id:req.body.id,
                        type: "children"
                    },
                    {
                        quantity: 1,
                    });    
                    for(let i =0; i<children_count.length;i++)
                    {
                        CHILDREN_COUNT += children_count[i].quantity;
                    }                     
                    res.status(200).json({"data":[WOMEN_COUNT,MEN_COUNT,CHILDREN_COUNT]});      
            }
            else res.status(200).json("user not found");
        }
        else
        {
            const user = await userModel3.findById(req.body.id);
            if(user)
            {
               const women_count = await productModel3.find({ 
                post_date: {
                        $gte: new Date(req.body.startDate), 
                        $lte: new Date(req.body.endDate)
                    },               
                    status:"purchased",
                    user_id:req.body.id,
                    type: "women"
                },
                {
                    quantity: 1,
                })/*.count()*/; 
                for(let i =0; i<women_count.length;i++)
                {
                    WOMEN_COUNT += women_count[i].quantity;
                }

                const men_count = await productModel3.find({ 
                    post_date: {
                            $gte: new Date(req.body.startDate),
                            $lte: new Date(req.body.endDate)
                        },
                        status:"purchased",
                        user_id:req.body.id,
                        type: "men"
                    },
                    {
                        quantity: 1,
                    });    
                    for(let i =0; i<men_count.length;i++)
                    {
                        MEN_COUNT += men_count[i].quantity;
                    }              
                const children_count = await productModel3.find({ 
                    post_date: {
                            $gte: new Date(req.body.startDate),
                            $lte: new Date(req.body.endDate)
                        },
                        status:"purchased",
                        user_id:req.body.id,
                        type: "children"
                    },
                    {
                        quantity: 1,
                    });    
                    for(let i =0; i<children_count.length;i++)
                    {
                        CHILDREN_COUNT += children_count[i].quantity;
                    }                     
                res.status(200).json({"data":[WOMEN_COUNT,MEN_COUNT,CHILDREN_COUNT]});    
            }
            else res.status(200).json("user not found");
        }
    }
    catch (err) {
        res.status(200).json("user not found");
        console.log(err);
        }
});

//report of sold items
router.post('/soldReport',cors(corsOptions), async (req, res) => {
    try
    {
        var women =0;
        var men =0;
        var children =0;

        const women_count1 = await productModel1.find({ 
        post_date: {
                $gte: new Date(req.body.startDate), 
                $lte: new Date(req.body.endDate)
            },               
            status:"purchased",
            owner_id:req.body.id,
            type: "women"
        },
        {
            quantity: 1,
        }); 
        for(let i =0; i<women_count1.length;i++)
        {
            women += women_count1[i].quantity;
        }   
        const women_count2 = await productModel2.find({ 
            post_date: {
                    $gte: new Date(req.body.startDate), 
                    $lte: new Date(req.body.endDate)
                },               
                status:"purchased",
                owner_id:req.body.id,
                type: "women"
            },
            {
                quantity: 1,
            }); 
            for(let i =0; i<women_count2.length;i++)
            {
                women += women_count2[i].quantity;
            }   
        const women_count3 = await productModel3.find({ 
            post_date: {
                    $gte: new Date(req.body.startDate), 
                    $lte: new Date(req.body.endDate)
                },               
                status:"purchased",
                owner_id:req.body.id,
                type: "women"
            },
            {
                quantity: 1,
            }); 
            for(let i =0; i<women_count3.length;i++)
            {
                women += women_count3[i].quantity;
            }   

            //women = women_count1+ women_count2+women_count3;

        const men_count1 = await productModel1.find({ 
            post_date: {
                    $gte: new Date(req.body.startDate),
                    $lte: new Date(req.body.endDate)
                },
                status:"purchased",
                owner_id:req.body.id,
                type: "men"
            },
            {
                quantity: 1,
            }); 
            for(let i =0; i<men_count1.length;i++)
            {
                men += men_count1[i].quantity;
            }       
        const men_count2 = await productModel2.find({ 
            post_date: {
                    $gte: new Date(req.body.startDate),
                    $lte: new Date(req.body.endDate)
                },
                status:"purchased",
                owner_id:req.body.id,
                type: "men"
            },
            {
                quantity: 1,
            }); 
            for(let i =0; i<men_count2.length;i++)
            {
                men += men_count2[i].quantity;
            }    
        const men_count3 = await productModel3.find({ 
            post_date: {
                    $gte: new Date(req.body.startDate),
                    $lte: new Date(req.body.endDate)
                },
                status:"purchased",
                owner_id:req.body.id,
                type: "men"
            },
            {
                quantity: 1,
            }); 
            for(let i =0; i<men_count3.length;i++)
            {
                men += men_count3[i].quantity;
            }        

           // men = men_count1+men_count2+men_count3;

        const children_count1 = await productModel1.find({ 
            post_date: {
                    $gte: new Date(req.body.startDate),
                    $lte: new Date(req.body.endDate)
                },
                status:"purchased",
                owner_id:req.body.id,
                type: "children"
            },
            {
                quantity: 1,
            }); 
            for(let i =0; i<children_count1.length;i++)
            {
                children += children_count1[i].quantity;
            }          
        const children_count2 = await productModel2.find({ 
            post_date: {
                    $gte: new Date(req.body.startDate),
                    $lte: new Date(req.body.endDate)
                },
                status:"purchased",
                owner_id:req.body.id,
                type: "children"
            },
            {
                quantity: 1,
            }); 
            for(let i =0; i<children_count2.length;i++)
            {
                children += children_count2[i].quantity;
            }     
        const children_count3 = await productModel3.find({ 
            post_date: {
                    $gte: new Date(req.body.startDate),
                    $lte: new Date(req.body.endDate)
                },
                status:"purchased",
                owner_id:req.body.id,
                type: "children"
            },
            {
                quantity: 1,
            }); 
            for(let i =0; i<children_count3.length;i++)
            {
                children += children_count3[i].quantity;
            }         
            
           // children= children_count1+children_count2+children_count3;

        res.status(200).json({"data":[women,men,children]});    
    }
    catch (err) {
        res.status(200).json("failed");
        console.log(err);
        }
});

// edit product 
router.put("/product/edit",cors(corsOptions), async (req, res) => {   
    try {
        if(req.body.region === 'Asia' || req.body.region === 'Europe')
        {
            const product = await productModel1.findByIdAndUpdate(req.body.product_id, {
                $set: req.body, // to set all inputs inside this body (the body written in postman)
            });
            if(product)
            res.status(200).json("Success");
            else 
            res.status(200).json("product not found");
        }
        else if (req.body.region === 'North America' || req.body.region === 'South America')
        {
            const product = await productModel2.findByIdAndUpdate(req.body.product_id, {
                $set: req.body,
            });
            if(product)
            res.status(200).json("Success");
            else 
            res.status(200).json("product not found");
        }
        else
        {
            const product = await productModel3.findByIdAndUpdate(req.body.product_id, {
                $set: req.body,
            });
            if(product)
            res.status(200).json("Success");
            else 
            res.status(200).json("product not found");
        }
    }
    catch (err) {
    res.status(200).json("product not found");
    console.log(err);
    }
    
  });

  // delete product 
  router.delete("/product/delete",cors(corsOptions), async (req, res) => {   
    try 
    {
        if(req.body.region === 'Asia' || req.body.region === 'Europe')
        {
            await productModel1.findByIdAndDelete(req.body.product_id);
            res.status(200).json("Success");
            
        }
        else if (req.body.region === 'North America' || req.body.region === 'South America')
        {
            await productModel2.findByIdAndDelete(req.body.product_id);
            res.status(200).json("Success");
        }
        else
        {
            await productModel3.findByIdAndDelete(req.body.product_id);
            res.status(200).json("Success");
        }

    }
    catch (err) {
        res.status(200).json("product not found");
        console.log(err);
        }
        
      });

// delete one item in cart 
router.delete("/cart/delete",cors(corsOptions), async (req, res) => {   
    try 
    {
        if(req.body.region === 'Asia' || req.body.region === 'Europe')
        {
            await cartModel1.deleteOne({
                user_id:req.body.user_id,
                product_id:req.body.product_id
            });
            res.status(200).json("Success");
            
        }
        else if (req.body.region === 'North America' || req.body.region === 'South America')
        {
            await cartModel2.deleteOne({
                user_id:req.body.user_id,
                product_id:req.body.product_id
            });
            res.status(200).json("Success");
        }
        else
        {
            await cartModel3.deleteOne({
                user_id:req.body.user_id,
                product_id:req.body.product_id
            });
            res.status(200).json("Success");
        }

    }
    catch (err) {
        res.status(200).json("cart not found");
        console.log(err);
        }
        
      });

// delete all items of this product in cart
      router.delete("/cart/deleteX",cors(corsOptions), async (req, res) => {   
        try 
        {
            if(req.body.region === 'Asia' || req.body.region === 'Europe')
            {
                await cartModel1.deleteMany({
                    user_id:req.body.user_id,
                    product_id:req.body.product_id
                });
                res.status(200).json("Success");
                
            }
            else if (req.body.region === 'North America' || req.body.region === 'South America')
            {
                await cartModel2.deleteMany({
                    user_id:req.body.user_id,
                    product_id:req.body.product_id
                });
                res.status(200).json("Success");
            }
            else
            {
                await cartModel3.deleteMany({
                    user_id:req.body.user_id,
                    product_id:req.body.product_id
                });
                res.status(200).json("Success");
            }
    
        }
        catch (err) {
            res.status(200).json("cart not found");
            console.log(err);
            }
            
          });
    


module.exports=router;

