const router = require('express').Router();
const bcrypt = require ('bcryptjs');
const mongoose = require('mongoose');
const UserSchema = require("../models/User");
const cors = require('cors');

var corsOptions = {
  
    "origin": "*",
    "methods": "GET,HEAD,PUT,PATCH,POST,DELETE",
    "preflightContinue": false,
    "optionsSuccessStatus": 200
  
}

//////////////
//connect to first server
const connection1 = mongoose.createConnection(
	"mongodb+srv://server1:server1@cluster0.vtt0a.mongodb.net/server1?retryWrites=true&w=majority",
	{ useNewUrlParser: true, useUnifiedTopology: true },
	() => {
		console.log(`server1  is connected successfully `);
	}
);
const userModel1 = connection1.model("User",UserSchema);


//connect to second server
const connection2 = mongoose.createConnection(
	"mongodb+srv://server2:server2@cluster0.uhp2r.mongodb.net/server2?retryWrites=true&w=majority",
	{ useNewUrlParser: true, useUnifiedTopology: true },
	() => {
		console.log(`server2  is connected successfully `);
	}
);

const userModel2 = connection2.model("User",UserSchema);

//connect to third server
const connection3 = mongoose.createConnection(
	"mongodb+srv://server3:server3@cluster0.7v7gj.mongodb.net/server3?retryWrites=true&w=majority",
	{ useNewUrlParser: true, useUnifiedTopology: true },
	() => {
		console.log(`server3  is connected successfully `);
	}
);

const userModel3 = connection3.model("User",UserSchema);

//////////////


//register 
router.post('/register',cors(corsOptions),async(req,res)=>{
    try{
        //generate new password
        const salt = await bcrypt.genSalt(10);
        const hashedPassword = await bcrypt.hash(req.body.password,salt)//to hash pass
        // create new user 
        if(req.body.region === 'Asia' || req.body.region === 'Europe'){
          newUser = await userModel1.create({
            username:req.body.username,
            email:req.body.email,
            region:req.body.region,
            password:hashedPassword,
            mobile_number:req.body.mobile_number
          });
          
          res.status(200).json({"Success":newUser}); 
        }

      else if (req.body.region === 'North America' || req.body.region === 'South America')
      {
          newUser = await userModel2.create({
            username:req.body.username,
            email:req.body.email,
            region:req.body.region,
            password:hashedPassword,
            mobile_number:req.body.mobile_number
          });
          
          res.status(200).json({"Success":newUser}); 
      }
      else 
      {
          newUser = await userModel3.create({
            username:req.body.username,
            email:req.body.email,
            region:req.body.region,
            password:hashedPassword,
            mobile_number:req.body.mobile_number
          });
          
          res.status(200).json({"Success":newUser}); 
      }
       
    }
      

    catch(err){
        res.status(200).json("username or email registered before");
        console.log (err);
    }
    
});

//login
router.post("/login",cors(corsOptions), async (req, res) => {
    try {
      if(req.body.region === 'Asia' || req.body.region === 'Europe'){
        //search in basic db server ==>server1
        const user = await userModel1.findOne({ email: req.body.email });
        !user && res.status(200).json("wrong email");
    
        const validPassword = await bcrypt.compare(req.body.password, user.password);
        !validPassword && res.status(200).json("wrong password");

        
        res.status(200).json({"Success":user});
      }
      else if (req.body.region === 'North America' || req.body.region === 'South America')
      {
        //search in basic db server ==>server2
        const user = await userModel2.findOne({ email: req.body.email });
        !user && res.status(200).json("wrong email");
    
        const validPassword = await bcrypt.compare(req.body.password, user.password);
        !validPassword && res.status(200).json("wrong password");

        
        res.status(200).json({"Success":user});
      }
      else
      {
        //search in basic db server ==>server3
        const user = await userModel3.findOne({ email: req.body.email });
        !user && res.status(200).json("wrong email");
    
        const validPassword = await bcrypt.compare(req.body.password, user.password);
        !validPassword && res.status(200).json("wrong password");

        
        res.status(200).json({"Success":user});
      }
      // res.status(200).json(user);

    } catch (err) {
     // res.status(500).json(err);
      console.log(err);
    }
  });
module.exports = router;